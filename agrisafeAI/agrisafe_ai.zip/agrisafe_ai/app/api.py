import json
from pathlib import Path
from uuid import uuid4
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from sqlalchemy.orm import Session
from pypdf import PdfReader
from .db import get_db
from .models import Assessment
from .schemas import AssessmentRequest, AssessmentResponse, SaferWindowRequest
from .risk_engine import assess
from .weather import get_weather
from .knowledge import retrieve
from .config import settings

router = APIRouter(prefix="/api")


async def _resolve_weather(req):
    values = {
        "temperature_c": req.temperature_c,
        "humidity_pct": req.humidity_pct,
        "wind_kmh": req.wind_kmh,
        "rain_probability_pct": req.rain_probability_pct,
    }
    if all(v is not None for v in values.values()):
        return {**values, "source": "manual", "timestamp": None}
    return await get_weather(req.latitude, req.longitude, req.demo_mode)


@router.get("/health")
def health():
    return {"status": "ok", "service": "agrisafe-ai"}


@router.post("/assessments", response_model=AssessmentResponse)
async def create_assessment(req: AssessmentRequest, db: Session = Depends(get_db)):
    try:
        weather = await _resolve_weather(req)
    except Exception as exc:
        raise HTTPException(status_code=503, detail=str(exc)) from exc

    result = assess(
        task=req.task,
        crop=req.crop,
        temperature_c=weather["temperature_c"],
        humidity_pct=weather["humidity_pct"],
        wind_kmh=weather["wind_kmh"],
        rain_probability_pct=weather["rain_probability_pct"],
        worker_exposure_hours=req.worker_exposure_hours,
        ppe_complete=req.ppe_complete,
        chemical=req.chemical,
    )

    assessment = Assessment(
        crop=req.crop,
        task=req.task,
        planned_time=req.planned_time,
        duration_minutes=req.duration_minutes,
        latitude=req.latitude,
        longitude=req.longitude,
        chemical=req.chemical,
        temperature_c=weather["temperature_c"],
        humidity_pct=weather["humidity_pct"],
        wind_kmh=weather["wind_kmh"],
        rain_probability_pct=weather["rain_probability_pct"],
        worker_exposure_hours=req.worker_exposure_hours,
        ppe_complete=req.ppe_complete,
        risk_score=result.score,
        risk_level=result.level,
        decision=result.decision,
        reasons_json=json.dumps(result.reasons),
        actions_json=json.dumps(result.actions),
        rules_json=json.dumps(result.rules + [f"BLOCKER:{x}" for x in result.blockers]),
        weather_source=weather.get("source", "unknown"),
        weather_timestamp=weather.get("timestamp"),
    )
    db.add(assessment)
    db.commit()
    db.refresh(assessment)

    status = "INCOMPLETE" if result.blockers else "COMPLETE"
    return AssessmentResponse(
        id=assessment.id,
        created_at=assessment.created_at,
        risk_score=result.score,
        risk_level=result.level,
        decision=result.decision,
        reasons=result.reasons + result.blockers,
        actions=result.actions,
        rules_triggered=result.rules,
        weather=weather,
        assessment_status=status,
    )


@router.get("/assessments")
def list_assessments(db: Session = Depends(get_db)):
    rows = db.query(Assessment).order_by(Assessment.created_at.desc()).limit(50).all()
    return [
        {
            "id": r.id,
            "created_at": r.created_at,
            "crop": r.crop,
            "task": r.task,
            "risk_score": r.risk_score,
            "risk_level": r.risk_level,
            "decision": r.decision,
        }
        for r in rows
    ]


@router.post("/safer-windows")
async def safer_windows(req: SaferWindowRequest):
    # A deterministic demo forecast lets the hackathon feature work without a second external API.
    candidates = [
        {"label": "Now", "temperature_c": 34, "humidity_pct": 82, "wind_kmh": 18, "rain_probability_pct": 70},
        {"label": "+1 hour", "temperature_c": 33, "humidity_pct": 80, "wind_kmh": 15, "rain_probability_pct": 60},
        {"label": "+2 hours", "temperature_c": 31, "humidity_pct": 78, "wind_kmh": 10, "rain_probability_pct": 35},
        {"label": "+3 hours", "temperature_c": 29, "humidity_pct": 76, "wind_kmh": 7, "rain_probability_pct": 20},
        {"label": "+4 hours", "temperature_c": 28, "humidity_pct": 75, "wind_kmh": 6, "rain_probability_pct": 15},
    ]
    results = []
    for c in candidates:
        r = assess(
            task=req.task,
            crop=req.crop,
            temperature_c=c["temperature_c"],
            humidity_pct=c["humidity_pct"],
            wind_kmh=c["wind_kmh"],
            rain_probability_pct=c["rain_probability_pct"],
            worker_exposure_hours=req.worker_exposure_hours,
            ppe_complete=req.ppe_complete,
            chemical=req.chemical,
        )
        results.append({**c, "risk_score": r.score, "risk_level": r.level, "decision": r.decision})
    viable = [x for x in results if x["decision"] in {"PROCEED", "MODIFY"}]
    viable.sort(key=lambda x: x["risk_score"])
    return {"windows": results, "recommended": viable[0] if viable else None}


@router.get("/knowledge/search")
def knowledge_search(q: str):
    return {"query": q, "results": retrieve(q)}


@router.post("/documents/extract")
async def extract_document(file: UploadFile = File(...)):
    allowed = {"application/pdf", "text/plain"}
    if file.content_type not in allowed:
        raise HTTPException(status_code=415, detail="Only PDF and text files are supported in the MVP.")
    content = await file.read()
    max_bytes = settings.max_upload_mb * 1024 * 1024
    if len(content) > max_bytes:
        raise HTTPException(status_code=413, detail=f"File is larger than {settings.max_upload_mb} MB.")
    text = ""
    if file.content_type == "application/pdf":
        temp = Path("/tmp") / f"agrisafe_{uuid4().hex}.pdf"
        temp.write_bytes(content)
        try:
            reader = PdfReader(str(temp))
            text = "\n".join((page.extract_text() or "") for page in reader.pages)
        finally:
            temp.unlink(missing_ok=True)
    else:
        text = content.decode("utf-8", errors="replace")
    return {"filename": file.filename, "characters": len(text), "text_preview": text[:8000]}
