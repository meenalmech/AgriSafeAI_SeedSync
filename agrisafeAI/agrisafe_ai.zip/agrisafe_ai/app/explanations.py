def decision_summary(result):
    if result.decision == "PROCEED":
        return "Conditions are within the configured prototype thresholds. Complete the normal safety checklist before starting."
    if result.decision == "MODIFY":
        return "The task may be possible after applying the listed controls and reassessing conditions."
    if result.decision == "DELAY":
        return "The current conditions are unfavorable. Wait for a safer window and reassess before starting."
    return "Do not rely on this assessment to proceed. Resolve the listed blockers or high-risk conditions first."
