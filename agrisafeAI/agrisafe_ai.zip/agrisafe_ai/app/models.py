from datetime import datetime, timezone
from sqlalchemy import DateTime, Float, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column
from .db import Base


class Assessment(Base):
    __tablename__ = "assessments"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=lambda: datetime.now(timezone.utc))
    crop: Mapped[str] = mapped_column(String(100))
    task: Mapped[str] = mapped_column(String(100))
    planned_time: Mapped[str] = mapped_column(String(40))
    duration_minutes: Mapped[int] = mapped_column(Integer)
    latitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    longitude: Mapped[float | None] = mapped_column(Float, nullable=True)
    chemical: Mapped[str | None] = mapped_column(String(150), nullable=True)
    temperature_c: Mapped[float] = mapped_column(Float)
    humidity_pct: Mapped[float] = mapped_column(Float)
    wind_kmh: Mapped[float] = mapped_column(Float)
    rain_probability_pct: Mapped[float] = mapped_column(Float)
    worker_exposure_hours: Mapped[float] = mapped_column(Float)
    ppe_complete: Mapped[bool] = mapped_column(default=False)
    risk_score: Mapped[int] = mapped_column(Integer)
    risk_level: Mapped[str] = mapped_column(String(30))
    decision: Mapped[str] = mapped_column(String(30))
    reasons_json: Mapped[str] = mapped_column(Text)
    actions_json: Mapped[str] = mapped_column(Text)
    rules_json: Mapped[str] = mapped_column(Text)
    weather_source: Mapped[str] = mapped_column(String(100), default="manual")
    weather_timestamp: Mapped[str | None] = mapped_column(String(80), nullable=True)
