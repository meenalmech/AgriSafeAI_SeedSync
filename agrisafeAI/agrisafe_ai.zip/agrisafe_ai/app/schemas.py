from datetime import datetime
from pydantic import BaseModel, Field


class AssessmentRequest(BaseModel):
    crop: str = Field(min_length=1, max_length=100)
    task: str = Field(min_length=1, max_length=100)
    planned_time: str = Field(min_length=1, max_length=40)
    duration_minutes: int = Field(default=60, ge=15, le=720)
    latitude: float | None = Field(default=None, ge=-90, le=90)
    longitude: float | None = Field(default=None, ge=-180, le=180)
    chemical: str | None = Field(default=None, max_length=150)
    temperature_c: float | None = Field(default=None, ge=-50, le=70)
    humidity_pct: float | None = Field(default=None, ge=0, le=100)
    wind_kmh: float | None = Field(default=None, ge=0, le=250)
    rain_probability_pct: float | None = Field(default=None, ge=0, le=100)
    worker_exposure_hours: float = Field(default=0, ge=0, le=24)
    ppe_complete: bool = False
    demo_mode: bool = False


class AssessmentResponse(BaseModel):
    id: int
    created_at: datetime
    risk_score: int
    risk_level: str
    decision: str
    reasons: list[str]
    actions: list[str]
    rules_triggered: list[str]
    weather: dict
    assessment_status: str


class SaferWindowRequest(BaseModel):
    crop: str
    task: str
    latitude: float | None = None
    longitude: float | None = None
    chemical: str | None = None
    duration_minutes: int = Field(default=60, ge=15, le=720)
    worker_exposure_hours: float = Field(default=0, ge=0, le=24)
    ppe_complete: bool = False
    demo_mode: bool = False
