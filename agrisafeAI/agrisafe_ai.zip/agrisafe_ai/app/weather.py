from datetime import datetime, timezone
import httpx
from .config import settings

DEMO_WEATHER = {
    "temperature_c": 34.0,
    "humidity_pct": 82.0,
    "wind_kmh": 18.0,
    "rain_probability_pct": 70.0,
    "source": "demo",
    "timestamp": datetime.now(timezone.utc).isoformat(),
}


async def get_weather(latitude: float | None, longitude: float | None, demo_mode: bool = False) -> dict:
    if latitude is None or longitude is None:
        if demo_mode and settings.demo_weather_enabled:
            return {**DEMO_WEATHER, "warning": "Demo weather. Enter coordinates for live weather."}
        raise ValueError("Latitude and longitude are required for live weather.")

    url = "https://api.open-meteo.com/v1/forecast"
    params = {
        "latitude": latitude,
        "longitude": longitude,
        "current": "temperature_2m,relative_humidity_2m,wind_speed_10m",
        "hourly": "precipitation_probability",
        "forecast_days": 1,
        "timezone": "auto",
    }
    try:
        async with httpx.AsyncClient(timeout=settings.request_timeout_seconds) as client:
            response = await client.get(url, params=params)
            response.raise_for_status()
            payload = response.json()
        current = payload.get("current", {})
        hourly = payload.get("hourly", {})
        rain = (hourly.get("precipitation_probability") or [0])[0]
        return {
            "temperature_c": float(current.get("temperature_2m", 0)),
            "humidity_pct": float(current.get("relative_humidity_2m", 0)),
            "wind_kmh": float(current.get("wind_speed_10m", 0)),
            "rain_probability_pct": float(rain or 0),
            "source": "Open-Meteo",
            "timestamp": current.get("time") or datetime.now(timezone.utc).isoformat(),
        }
    except Exception as exc:
        if demo_mode and settings.demo_weather_enabled:
            return {**DEMO_WEATHER, "warning": f"Live weather unavailable; demo weather used: {type(exc).__name__}"}
        raise RuntimeError("Live weather service is unavailable. Reassess when weather data is available.") from exc
