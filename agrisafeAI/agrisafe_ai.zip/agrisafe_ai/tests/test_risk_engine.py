from app.risk_engine import assess


def test_high_risk_spraying():
    r = assess("Pesticide spraying", "Chili", 34, 82, 18, 70, 4, False, "Demo Pesticide X")
    assert r.decision in {"DELAY", "AVOID"}
    assert r.score >= 55
    assert "SPRAY_WIND_ELEVATED" in r.rules
    assert "PPE_INCOMPLETE" in r.rules


def test_missing_chemical_is_incomplete():
    r = assess("Pesticide spraying", "Chili", 29, 70, 5, 10, 1, True, None)
    assert r.level == "INCOMPLETE"
    assert r.decision == "AVOID"
    assert "CHEMICAL_MISSING" in r.rules


def test_low_risk_basic_task():
    r = assess("Field inspection", "Chili", 27, 65, 5, 10, 1, True, None)
    assert r.decision == "PROCEED"
    assert r.score <= 30
