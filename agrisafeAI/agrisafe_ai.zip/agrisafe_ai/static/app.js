const form = document.getElementById('assessmentForm');
const errorBox = document.getElementById('formError');
const resultContent = document.getElementById('resultContent');
const emptyState = document.getElementById('emptyState');
let lastPayload = null;

function val(form, name){ return form.elements[name].value; }
function numberOrNull(v){ return v === '' ? null : Number(v); }

form.addEventListener('submit', async (e) => {
  e.preventDefault();
  errorBox.textContent = '';
  const payload = {
    crop: val(form,'crop'), task: val(form,'task'), planned_time: val(form,'planned_time'),
    duration_minutes: Number(val(form,'duration_minutes')),
    latitude: numberOrNull(val(form,'latitude')), longitude: numberOrNull(val(form,'longitude')),
    chemical: val(form,'chemical') || null,
    temperature_c: numberOrNull(val(form,'temperature_c')), humidity_pct: numberOrNull(val(form,'humidity_pct')),
    wind_kmh: numberOrNull(val(form,'wind_kmh')), rain_probability_pct: numberOrNull(val(form,'rain_probability_pct')),
    worker_exposure_hours: Number(val(form,'worker_exposure_hours')),
    ppe_complete: form.elements['ppe_complete'].checked,
    demo_mode: form.elements['demo_mode'].checked
  };
  lastPayload = payload;
  try {
    const res = await fetch('/api/assessments',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
    const data = await res.json();
    if(!res.ok) throw new Error(data.detail || 'Assessment failed');
    renderResult(data);
    loadHistory();
  } catch(err){ errorBox.textContent = err.message; }
});

function renderResult(data){
  emptyState.hidden = true; resultContent.hidden = false;
  document.getElementById('decision').textContent = data.decision;
  document.getElementById('decision').className = data.decision;
  document.getElementById('score').textContent = `${data.risk_score}/100`;
  document.getElementById('level').textContent = data.risk_level;
  document.getElementById('level').className = `level ${data.decision}`;
  const summary = data.decision === 'PROCEED' ? 'Conditions are within the configured prototype thresholds. Complete the normal checklist.' : data.decision === 'MODIFY' ? 'Apply the listed controls and reassess before starting.' : data.decision === 'DELAY' ? 'Wait for a safer window and reassess before starting.' : 'Do not treat this as a safe-to-proceed decision until the listed issues are resolved.';
  document.getElementById('summary').textContent = summary;
  document.getElementById('reasons').innerHTML = data.reasons.map(x=>`<li>${escapeHtml(x)}</li>`).join('');
  document.getElementById('actions').innerHTML = data.actions.map(x=>`<li>${escapeHtml(x)}</li>`).join('');
  document.getElementById('rules').innerHTML = data.rules_triggered.map(x=>`<span class="chip">${escapeHtml(x)}</span>`).join('');
  const w = data.weather;
  document.getElementById('weather').innerHTML = `<div class="weather-grid"><div><strong>${w.temperature_c}°C</strong><small>Temp</small></div><div><strong>${w.humidity_pct}%</strong><small>Humidity</small></div><div><strong>${w.wind_kmh} km/h</strong><small>Wind</small></div><div><strong>${w.rain_probability_pct}%</strong><small>Rain</small></div></div><small>Source: ${escapeHtml(w.source || 'unknown')}</small>`;
  document.getElementById('saferResult').innerHTML = '';
}

document.getElementById('saferButton').addEventListener('click', async ()=>{
  if(!lastPayload) return;
  const body = {crop:lastPayload.crop,task:lastPayload.task,latitude:lastPayload.latitude,longitude:lastPayload.longitude,chemical:lastPayload.chemical,duration_minutes:lastPayload.duration_minutes,worker_exposure_hours:lastPayload.worker_exposure_hours,ppe_complete:lastPayload.ppe_complete,demo_mode:true};
  const box = document.getElementById('saferResult'); box.textContent='Searching windows...';
  try{
    const res=await fetch('/api/safer-windows',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)});
    const data=await res.json(); if(!res.ok) throw new Error(data.detail || 'Unable to search');
    box.innerHTML = data.recommended ? `<div class="window recommended"><strong>Recommended window: ${data.recommended.label}</strong><br>${data.recommended.temperature_c}°C · ${data.recommended.wind_kmh} km/h wind · ${data.recommended.rain_probability_pct}% rain · ${data.recommended.risk_score}/100 · ${data.recommended.decision}</div>` : '<div class="window">No suitable lower-risk window found in the demo horizon.</div>';
    box.innerHTML += data.windows.map(w=>`<div class="window"><strong>${w.label}</strong> · ${w.risk_score}/100 · ${w.decision}</div>`).join('');
  }catch(err){ box.textContent=err.message; }
});

document.getElementById('refreshHistory').addEventListener('click', loadHistory);
async function loadHistory(){
  const el=document.getElementById('history');
  try{
    const res=await fetch('/api/assessments'); const rows=await res.json();
    if(!rows.length){el.textContent='No assessments yet.';return;}
    el.innerHTML=`<table class="history-table"><thead><tr><th>ID</th><th>Time</th><th>Crop</th><th>Task</th><th>Risk</th><th>Decision</th></tr></thead><tbody>${rows.map(r=>`<tr><td>${r.id}</td><td>${new Date(r.created_at).toLocaleString()}</td><td>${escapeHtml(r.crop)}</td><td>${escapeHtml(r.task)}</td><td>${r.risk_score}/100</td><td class="decision ${r.decision}">${r.decision}</td></tr>`).join('')}</tbody></table>`;
  }catch(err){el.textContent='History unavailable.';}
}
function escapeHtml(s){return String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
loadHistory();
